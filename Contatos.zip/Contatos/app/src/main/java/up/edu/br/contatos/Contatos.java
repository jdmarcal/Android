package up.edu.br.contatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Contatos extends AppCompatActivity {

    Contato contato;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contatos);


        EditText txtNome = (EditText)findViewById(R.id.txtNome);
        EditText txtTelefone = (EditText)findViewById(R.id.txtTelefone);
        Spinner spTipo = (Spinner)findViewById(R.id.spTipo);


    Intent it = getIntent();

    if (it != null && it.hasExtra("contato")){



       contato = (Contato) it.getSerializableExtra("contato");

       txtNome.setText(contato.getName());
       spTipo.setSelection(((ArrayAdapter)spTipo.getAdapter()).getPosition(contato.getTipo()));
       txtTelefone.setText(contato.getNumero());


        //Toast.makeText(getApplicationContext(),"Contato" +c.getName(), Toast.LENGTH_LONG).show();


    }

        }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_contato, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        //noinspection SimplifiableIfStatement
        if (id == R.id.save) {
            EditText txtNome = (EditText)findViewById(R.id.txtNome);
            EditText txtTelefone = (EditText)findViewById(R.id.txtTelefone);
            Spinner spTipo = (Spinner)findViewById(R.id.spTipo);

            if(contato == null) {
                contato = new Contato();
            }
            contato.setName(txtNome.getText().toString());
            contato.setTipo(spTipo.getSelectedItem().toString());
            contato.setNumero(txtTelefone.getText().toString());


            new ContatoDao().salvar(contato);


            Toast.makeText(getApplicationContext(),
                     "Salvo com sucesso! ",
                    Toast.LENGTH_LONG).show();


            Intent ite = new Intent(Contatos.this, MainActivity.class);
            startActivity(ite);

            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
