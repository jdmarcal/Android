package up.edu.br.contatos;

import java.io.Serializable;

public class Contato  implements Serializable{

    private Integer id;
    private String name;
    private String tipo;
    private String numero;
    private String apelido;

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    @Override
    public boolean equals(Object o){
        if(id == null || ((Contato)o).getId()== null){
            return false;
        }
        return id.equals(((Contato)o).getId());
    }

    @Override
    public int hashCode(){
        return id != null ? id.hashCode() : 0;
    }

    public String toString(){
        return name;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
